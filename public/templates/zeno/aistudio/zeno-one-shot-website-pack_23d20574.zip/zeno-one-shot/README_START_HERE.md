# ZENO. — Google AI Studio One-Shot Website Pack

This package contains the approved four 2K design references, seven extracted artwork crops, and a detailed implementation prompt.

## Quick start

1. Start a new website project in Google AI Studio or open the project you want to use.
2. Add the **contents of `assets/`** to the project, keeping directory names intact. If your AI Studio environment doesn't accept ZIP extraction, upload the four files from `assets/reference/` plus the seven WebPs from `assets/crops/` individually.
3. Open `ZENO_MASTER_PROMPT.md` and paste its full contents into the coding agent. Give the agent access to the assets.
4. Ask it to implement the entire website, not only produce a description. The master prompt includes this instruction already.
5. Review the resulting website at desktop and mobile sizes. Check the case-study dialogs, services selection, navigation, and contact demo mode.

## Source asset map

| Reference frame | Filename | Used for |
|---|---|---|
| Hero | `assets/reference/zeno-hero-reference.jpg` | Hero/header layout and typography |
| Expertise | `assets/reference/zeno-expertise-reference.jpg` | Four-discipline diagram |
| Selected Work | `assets/reference/zeno-work-reference.jpg` | Two case-study arrangements |
| Final CTA | `assets/reference/zeno-contact-reference.jpg` | Giant ring, CTA, footer |

## Artwork crops

`assets/crops/hero-collage.webp` — Hero visual collage.

`assets/crops/strategy-print.webp`, `identity-print.webp`, `campaign-print.webp`, `digital-print.webp` — Expertise artwork modules.

`assets/crops/auren-world.webp`, `morrow-world.webp` — Fictional case-study visuals.

**Note:** The crops are extracted from the final composed images and include some dark background pixels or printed words that are part of the artwork. They are not transparent editable Photoshop layers. For best results, use them as artwork inside real HTML/CSS sections with text/buttons rebuilt as DOM. Align with the existing dark background and use CSS masking only if needed.

## About the contact details

ZENO., Auren House, and Morrow Field are fictional concepts. `hello@zeno.studio` in the visual is example copy and its ownership was not verified. Connect a real inbox/form endpoint and real social profiles before public deployment. Don't claim the demonstration form sent an email without a backend.
